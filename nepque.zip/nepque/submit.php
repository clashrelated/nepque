<?php
session_start();

// Check if the user is logged in
if (isset($_SESSION["user_email"])) {
    // User is logged in
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["logout"])) {
        // If logout button is clicked, end the session
        session_unset();
        session_destroy();
        header("Location: index.php");
        exit();
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
        <!-- OG Meta Tags -->
    <meta property="og:title" content="NepQue - Coupon & Deals">
    <meta property="og:description" content="#1 Coupon Site in Nepal...">
    <meta property="og:image" content="https://bhabishyabhatt.com.np/nepque/nepque.jpg">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
    <meta property="og:url" content="https://bhabishyabhatt.com.np/nepque/">
    <meta name="twitter:card" content="summary_large_image">

    <title>Submit Coupon - NepQue</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        nav {
        display: flex;
        justify-content: space-between;
        align-items: center;
        background-color: #333;
        color: white;
        padding: 10px;
         background-color: #333;
            color: white;
    }
        nav a {
            color: white;
            text-decoration: none;
        }
    .nav-right {
        display: flex;
        align-items: center;
    }

    .nav-right a {
        color: white;
        text-decoration: none;
        margin-left: 15px;
    }

    .nav-right button {
        background-color: #13aa52;
        color: white;
        border: none;
        padding: 8px 12px;
        border-radius: 4px;
        cursor: pointer;
        margin-left: 15px;
    }

        .container {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 8px;
            font-weight: bold;
        }

        input[type="file"],
        input[type="text"] {
            margin-bottom: 16px;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #13aa52;
            color: white;
            border: none;
            padding: 10px;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #108743;
        }
    </style>
</head>
<body>

<!--Nav Bar-->
<nav>
    <div>
        <a href="index.php">NepQue</a>
    </div>
    <div class="nav-right">
        <?php
        if (isset($_SESSION["user_email"])) {
            // Show logout button if user is logged in
            echo '<form method="post"><button type="submit" name="logout">Logout</button></form>';
        } else {
            // Show login and signup links if user is not logged in
            echo '<a href="login.html">Login</a>';
            echo '<a href="signup.html">Sign-Up</a>';
        }
        ?>
    </div>
</nav>


<script>
function submitForm() {

  var xhr = new XMLHttpRequest(); 
  xhr.open("POST", "submit_coupon.php");

  xhr.onload = function() { 
    if(xhr.status === 200) {
      reloadPage();
    }
  };

  var data = new FormData(document.getElementById("couponForm"));
  xhr.send(data);

}

function reloadPage() {
  window.location.reload(); 
}

</script>

    <div class="container">
        <h2>Submit Coupon</h2>
<form id="couponForm" action="submit_coupon.php" onsubmit="submitForm(); reloadPage(); return false;" method="post" enctype="multipart/form-data">
            <label for="image_file">Coupon Image:</label>
            <input type="file" name="image_file" accept="image/*" required>

            <label for="coupon_text">Coupon Text:</label>
            <input type="text" name="coupon_text" required>

            <label for="coupon_code">Coupon Code:</label>
            <input type="text" name="coupon_code" required>
            
            <label for="website_name">Website Name:</label>
            <input type="text" name="website_name" required>

            <input type="submit" value="Submit Coupon">
        </form>
    </div>

</body>
</html>
