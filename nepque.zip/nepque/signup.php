<?php
$servername = "localhost";
$username = "cyrusflp_couponuser";
$password = "ijxKZ64a3k6vYJL";
$dbname = "cyrusflp_coupon";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $first_name = $_POST["first_name"];
    $last_name = $_POST["last_name"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT);

    // Check if email already exists
    $checkEmailSql = "SELECT id FROM users WHERE email = '$email'";
    $result = $conn->query($checkEmailSql);

    if ($result->num_rows > 0) {
        // Redirect back to signup page with error message
        header("Location: signup.html?error=This%20email%20is%20already%20registered.%20Please%20use%20a%20different%20email.");
        exit();
    } else {
        // Insert new user if email doesn't exist
        $sql = "INSERT INTO users (first_name, last_name, email, phone, password)
                VALUES ('$first_name', '$last_name', '$email', '$phone', '$password')";

        if ($conn->query($sql) === TRUE) {
            // Redirect to login.html
            header("Location: login.html");
            exit();
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}

$conn->close();
?>
