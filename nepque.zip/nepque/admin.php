<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        nav {
            background-color: #333;
            color: white;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        nav a {
            color: white;
            text-decoration: none;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #333;
            color: white;
        }

        .delete-btn {
            background-color: #ff5252;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
        }

        .delete-btn:hover {
            background-color: #ff0000;
        }
    </style>
</head>
<body>

    <nav>
        <div>
            <a href="https://bhabishyabhatt.com.np/nepque/">NepQue</a>
        </div>
        <div>
            <a href="login.html">Login</a>
            <a href="signup.html">Sign-Up</a>
            <a href="submit.php">Submit Coupon</a>
        </div>
    </nav>

    <div class="container">
        <h2>Coupon Details - Admin Panel</h2>
        <table>
            <tr>
                <th>ID</th>
                <th>Coupon Text</th>
                <th>Coupon Code</th>
                <th>Website Name</th>
                <th>Action</th>
            </tr>

            <?php
            $servername = "localhost";
            $username = "cyrusflp_couponuser";
            $password = "ijxKZ64a3k6vYJL";
            $dbname = "cyrusflp_coupon";

            $conn = new mysqli($servername, $username, $password, $dbname);

            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $sql = "SELECT * FROM coupons";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo '<tr>';
                    echo '<td>' . $row['id'] . '</td>';
                    echo '<td>' . $row['coupon_text'] . '</td>';
                    echo '<td>' . $row['coupon_code'] . '</td>';
                    echo '<td>' . $row['website_name'] . '</td>';
                    echo '<td><button class="delete-btn" onclick="deleteCoupon(' . $row['id'] . ')">Delete</button></td>';
                    echo '</tr>';
                }
            } else {
                echo '<tr><td colspan="5">No coupons available</td></tr>';
            }

            $conn->close();
            ?>
        </table>
    </div>

    <script>
        function deleteCoupon(id) {
            var confirmation = confirm("Are you sure you want to delete this coupon?");
            
            if (confirmation) {
                fetch('delete_coupon.php?id=' + id, {
                    method: 'DELETE'
                })
                .then(response => response.json())
                .then(data => {
                    alert(data.message);
                    location.reload();
                })
                .catch(error => console.error('Error:', error));
            }
        }
    </script>

</body>
</html>
