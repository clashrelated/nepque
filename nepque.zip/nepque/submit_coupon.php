<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION["user_email"])) {
    // Redirect to login page if not logged in
    header("Location: login.html");
    exit();
}
$servername = "localhost";
$username = "cyrusflp_couponuser";
$password = "ijxKZ64a3k6vYJL";
$dbname = "cyrusflp_coupon";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process image upload
$imageFile = $_FILES['image_file'];

// Check if the file is selected
if ($imageFile['error'] === UPLOAD_ERR_OK) {
    // Move the uploaded file to a destination directory (adjust the path as needed)
    $uploadDir = 'img/';
    $uploadedImagePath = $uploadDir . basename($imageFile['name']);

    if (move_uploaded_file($imageFile['tmp_name'], $uploadedImagePath)) {
        // Image uploaded successfully, proceed to insert data into the database
        $couponText = $_POST['coupon_text'];
        $couponCode = $_POST['coupon_code'];
        $websiteName = $_POST['website_name'];


$websiteName = $_POST['website_name'];

$sql = "INSERT INTO coupons (image_source, coupon_text, coupon_code, website_name) VALUES ('$uploadedImagePath', '$couponText', '$couponCode', '$websiteName')";

        if ($conn->query($sql) === TRUE) {
            echo "Coupon submitted successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Error uploading the image.";
    }
} else {
    echo "Error: " . $imageFile['error'];
}

$conn->close();
?>
