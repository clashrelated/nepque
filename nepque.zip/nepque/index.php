<!-- Include this PHP code at the top of your HTML/PHP file -->
<?php
session_start();

// Check if the user is logged in
if (isset($_SESSION["user_email"])) {
    // User is logged in
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["logout"])) {
        // If logout button is clicked, end the session
        session_unset();
        session_destroy();
        header("Location: login.html");
        exit();
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
        <!-- OG Meta Tags -->
    <meta property="og:title" content="NepQue - Coupon & Deals">
    <meta property="og:description" content="#1 Coupon Site in Nepal...">
    <meta property="og:image" content="https://bhabishyabhatt.com.np/nepque/nepque.jpg">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
    <meta property="og:url" content="https://bhabishyabhatt.com.np/nepque/">
    <meta name="twitter:card" content="summary_large_image">


    <title>Coupon Website</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        nav {
        display: flex;
        justify-content: space-between;
        align-items: center;
        background-color: #333;
        color: white;
        padding: 10px;
         background-color: #333;
            color: white;
    }

nav a {
            color: white;
            text-decoration: none;
        }
    .nav-right {
        display: flex;
        align-items: center;
    }

    .nav-right a {
        color: white;
        text-decoration: none;
        margin-left: 15px;
    }

    .nav-right button {
        background-color: #13aa52;
        color: white;
        border: none;
        padding: 8px 12px;
        border-radius: 4px;
        cursor: pointer;
        margin-left: 15px;
    }


        .container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            padding: 20px;
        }

        .coupon-box {
            width: 30%;
            margin-bottom: 20px;
            box-sizing: border-box;
            border: 1px solid #ccc; /* Add a border for better visualization */
        }

        .coupon-image {
            width: 100%;
            height: 300px; /* Adjust the height as needed */
            object-fit: cover;
        }

        .coupon-text {
            margin-top: 20px;
            text-align: center;
        }

        .coupon-code {
            margin-top: 10px;
            font-weight: bold;
            text-align: center;
        }

.button-37 a {
            color: white;
            text-decoration: none;
        }
        
        .button-37 {
            background-color: #13aa52;
            border: 1px solid #13aa52;
            border-radius: 4px;
            color: #fff;
            padding: 10px 25px;
            text-decoration: none;
            display: inline-block;
            text-align: center;
        }

        @media (min-width: 768px) {
            .coupon-box {
                width: 30%;
            }
        }
    </style>
</head>
<body>

<nav>
    <div>
        <a href="index.php">NepQue</a>
    </div>
    <div class="nav-right">
        <?php
        if (isset($_SESSION["user_email"])) {
            // Show logout button if user is logged in
            echo '<form method="post"><button type="submit" name="logout">Logout</button></form>';
            echo '<a href="submit.php">Submit Coupon</a>';
        } else {
            // Show login and signup links if user is not logged in
            echo '<a href="login.html">Login</a>';
            echo '<a href="signup.html">Sign-Up</a>';
        }
        ?>
    </div>
</nav>



    <div class="container">

        <?php
        $servername = "localhost";
        $username = "cyrusflp_couponuser";
        $password = "ijxKZ64a3k6vYJL";
        $dbname = "cyrusflp_coupon";

        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $sql = "SELECT * FROM coupons";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo '<div class="coupon-box">';
                echo '<img src="' . $row['image_source'] . '" alt="Coupon" class="coupon-image">';
                echo '<div class="coupon-text">' . $row['coupon_text'] . '</div>';
                echo '<div class="coupon-code" align="center">';
                echo '<button class="button-37"><a href="' . $row['website_name'] . '" target="_blank">' . $row['coupon_code'] . '</a></button>';
                echo '</div>';
                echo '</div>';
            }
        } else {
            echo "No coupons available";
        }

        $conn->close();
        ?>

    </div>

</body>
</html>
