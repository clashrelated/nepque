<?php
// Include your database connection logic here
$servername = "localhost";
$username = "cyrusflp_couponuser";
$password = "ijxKZ64a3k6vYJL";
$dbname = "cyrusflp_coupon";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if ID is provided in the URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Retrieve image source from the database
    $sql = "SELECT image_source FROM coupons WHERE id = $id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $imagePath = $row['image_source'];

        // Perform the DELETE query
        $sqlDelete = "DELETE FROM coupons WHERE id = $id";

        if ($conn->query($sqlDelete) === TRUE) {
            // Delete the associated image file
            if (file_exists($imagePath)) {
                unlink($imagePath);
            }

            $response = array('success' => true, 'message' => 'Coupon deleted successfully');
        } else {
            $response = array('success' => false, 'message' => 'Error deleting coupon: ' . $conn->error);
        }

        echo json_encode($response);
    } else {
        $response = array('success' => false, 'message' => 'Coupon not found');
        echo json_encode($response);
    }
} else {
    $response = array('success' => false, 'message' => 'Coupon ID not provided');
    echo json_encode($response);
}

$conn->close();
?>
