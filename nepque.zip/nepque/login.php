<?php
$servername = "localhost";
$username = "cyrusflp_couponuser";
$password = "ijxKZ64a3k6vYJL";
$dbname = "cyrusflp_coupon";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $password = $_POST["password"];

    // Check if email and password are correct
    $checkUserSql = "SELECT * FROM users WHERE email = '$email'";
    $result = $conn->query($checkUserSql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row["password"])) {
            // Start a session and store the user's email as a session variable
            session_start();
            $_SESSION["user_email"] = $email;

            // Redirect to submit.html
            header("Location: submit.php");
            exit();
        } else {
            echo "Error: Incorrect password";
        }
    } else {
        echo "Error: User not found";
    }
}

$conn->close();
?>
